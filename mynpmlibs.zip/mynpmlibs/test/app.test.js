describe('app', () => {
  beforeAll(async () => {
  })

  beforeEach(async () => {
  })

  it('should make sure of something', async () => {
    expect(true).toBe(true)
  })
})
