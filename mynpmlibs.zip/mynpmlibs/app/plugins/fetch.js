const got = require('got')

var url = 'https://api.npmjs.org/downloads/point/last-week/'

module.exports = function(app) {
  app.fetch = async function(name) {
    name = name.trim().toLowerCase()
    try {
      var response = await got(url + name)
      console.log(response.body)
      return JSON.parse(response.body)
    } catch (e) {
      console.log(e.message)
    }
  }
}
