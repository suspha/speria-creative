module.exports = async function($) {
  $.page.title = 'Libs'

  async function renderList() {
    var libs = await api({ action: 'lib/find' })
    console.log(libs)
    if (libs.length) {
      html('#list', /* html */`
        ${libs.map(lib => {
          return /* html */`
            <div class="flex list">
              <span>${esc(lib.name)}</span>
              <span>${esc(lib.downloads)}</span>
            </div>
          `
        }).join('')}
      `)
    } else {
      html('#list', `No libs found...`)
    }
  }

  return /* html */`
    <h1>Libs</h1>
    <div id="list">Loading...</div>
    <script>
      ${renderList}
      renderList()
    </script>
  `
}